﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace kriteek.Models.ViewModels
{
    public class PostVM
    {
    }
}